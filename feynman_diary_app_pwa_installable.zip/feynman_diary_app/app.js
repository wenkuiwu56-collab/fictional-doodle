const STORE_KEY = "feynman-diary-v1";
const prompts = [
  "今天有什么东西，我表面懂了，但让我用一句人话解释就卡壳？",
  "今天我看到的哪个现象最反直觉？它为什么会这样？",
  "如果让我把今天学到的东西讲给小学生，我会在哪一步说不清？",
  "今天哪个问题值得我明天继续追？最小验证动作是什么？",
  "我今天有没有把‘记住了’误判成‘理解了’？证据是什么？",
  "今天有什么习惯、情绪或环境因素，悄悄改变了我的表现？",
  "如果这件事背后有一个简单原理，它可能是什么？",
  "我今天问出的最好问题是什么？为什么它好？"
];

let state = loadState();
let editingDiaryId = null;
let editingQuestionId = null;

function loadState() {
  const raw = localStorage.getItem(STORE_KEY);
  if (!raw) return { diaries: [], questions: [] };
  try {
    const parsed = JSON.parse(raw);
    return {
      diaries: Array.isArray(parsed.diaries) ? parsed.diaries : [],
      questions: Array.isArray(parsed.questions) ? parsed.questions : []
    };
  } catch {
    return { diaries: [], questions: [] };
  }
}

function saveState() {
  localStorage.setItem(STORE_KEY, JSON.stringify(state));
  renderAll();
}

function uid() {
  return `${Date.now()}-${Math.random().toString(16).slice(2)}`;
}

function todayISO() {
  const d = new Date();
  const offset = d.getTimezoneOffset();
  return new Date(d.getTime() - offset * 60000).toISOString().slice(0, 10);
}

function formatDateTime(iso) {
  return new Date(iso).toLocaleString("zh-CN", { dateStyle: "medium", timeStyle: "short" });
}

function splitTags(str) {
  return str.split(/[,，\s]+/).map(t => t.trim()).filter(Boolean);
}

function showToast(msg) {
  const old = document.querySelector(".toast");
  if (old) old.remove();
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 1800);
}

function downloadFile(filename, content, mime) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function escapeHtml(text = "") {
  return text.replace(/[&<>'"]/g, char => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
  }[char]));
}

function setPrompt() {
  document.getElementById("promptText").textContent = prompts[Math.floor(Math.random() * prompts.length)];
}

function setupTabs() {
  document.querySelectorAll(".tab").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tab").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(btn.dataset.tab).classList.add("active");
      renderAll();
    });
  });
}

function saveDiary() {
  const title = document.getElementById("diaryTitle").value.trim() || "无标题日记";
  const mood = document.getElementById("diaryMood").value;
  const body = document.getElementById("diaryBody").value.trim();
  const tags = splitTags(document.getElementById("diaryTags").value);
  if (!body) return showToast("正文空空的，先写两句吧。")

  if (editingDiaryId) {
    state.diaries = state.diaries.map(item => item.id === editingDiaryId ? {
      ...item, title, mood, body, tags, updatedAt: new Date().toISOString()
    } : item);
    editingDiaryId = null;
    document.getElementById("saveDiary").textContent = "保存日记";
    showToast("日记已更新");
  } else {
    state.diaries.unshift({ id: uid(), title, mood, body, tags, createdAt: new Date().toISOString(), date: todayISO() });
    showToast("日记已保存");
  }
  ["diaryTitle", "diaryBody", "diaryTags"].forEach(id => document.getElementById(id).value = "");
  saveState();
}

function saveQuestion() {
  const text = document.getElementById("questionText").value.trim();
  const trigger = document.getElementById("questionTrigger").value.trim();
  const guess = document.getElementById("questionGuess").value.trim();
  const next = document.getElementById("questionNext").value.trim();
  const tags = splitTags(document.getElementById("questionTags").value);
  if (!text) return showToast("先写下那个疑问。")

  if (editingQuestionId) {
    state.questions = state.questions.map(item => item.id === editingQuestionId ? {
      ...item, text, trigger, guess, next, tags, updatedAt: new Date().toISOString()
    } : item);
    editingQuestionId = null;
    document.getElementById("saveQuestion").textContent = "保存疑问";
    showToast("疑问已更新");
  } else {
    state.questions.unshift({ id: uid(), text, trigger, guess, next, tags, status: "open", answer: "", createdAt: new Date().toISOString(), date: todayISO() });
    showToast("疑问已保存。好问题，先抓住它。")
  }
  ["questionText", "questionTrigger", "questionGuess", "questionNext", "questionTags"].forEach(id => document.getElementById(id).value = "");
  saveState();
}

function tagsHtml(tags = []) {
  return tags.map(t => `<span class="tag">#${escapeHtml(t)}</span>`).join("");
}

function renderDiaryList() {
  const query = document.getElementById("diarySearch")?.value.trim().toLowerCase() || "";
  const list = document.getElementById("diaryList");
  if (!list) return;
  const items = state.diaries.filter(item => [item.title, item.body, item.mood, ...(item.tags || [])].join(" ").toLowerCase().includes(query));
  if (!items.length) {
    list.innerHTML = `<div class="empty">还没有匹配的日记。今天先写三行也算赢。</div>`;
    return;
  }
  list.innerHTML = items.map(item => `
    <article class="entry">
      <div class="entry-head">
        <div>
          <h3>${escapeHtml(item.title)}</h3>
          <small>${formatDateTime(item.createdAt)} · 心情：${escapeHtml(item.mood || "未记录")}</small>
        </div>
        <div class="entry-actions">
          <button class="ghost" data-edit-diary="${item.id}">编辑</button>
          <button class="danger" data-delete-diary="${item.id}">删除</button>
        </div>
      </div>
      <p class="entry-body">${escapeHtml(item.body)}</p>
      <div class="tag-row">${tagsHtml(item.tags)}</div>
    </article>
  `).join("");
}

function statusLabel(status) {
  return { open: "未解决", exploring: "探索中", answered: "已解释" }[status] || "未解决";
}

function renderQuestionList() {
  const query = document.getElementById("questionSearch")?.value.trim().toLowerCase() || "";
  const filter = document.getElementById("questionStatusFilter")?.value || "all";
  const list = document.getElementById("questionList");
  if (!list) return;
  const items = state.questions.filter(item => {
    const matchesQuery = [item.text, item.trigger, item.guess, item.next, item.answer, ...(item.tags || [])].join(" ").toLowerCase().includes(query);
    const matchesStatus = filter === "all" || item.status === filter;
    return matchesQuery && matchesStatus;
  });
  if (!items.length) {
    list.innerHTML = `<div class="empty">还没有匹配的疑问。一个“不懂”就是一个入口。</div>`;
    return;
  }
  list.innerHTML = items.map(item => `
    <article class="entry">
      <div class="entry-head">
        <div>
          <h3>${escapeHtml(item.text)}</h3>
          <small>${formatDateTime(item.createdAt)} · <span class="tag status">${statusLabel(item.status)}</span></small>
        </div>
        <div class="entry-actions">
          <button class="ghost" data-status="${item.id}" data-value="open">未解决</button>
          <button class="ghost" data-status="${item.id}" data-value="exploring">探索中</button>
          <button class="ghost" data-status="${item.id}" data-value="answered">已解释</button>
          <button class="ghost" data-edit-question="${item.id}">编辑</button>
          <button class="danger" data-delete-question="${item.id}">删除</button>
        </div>
      </div>
      <p class="entry-body"><strong>触发：</strong>${escapeHtml(item.trigger || "未记录")}\n<strong>猜想：</strong>${escapeHtml(item.guess || "未记录")}\n<strong>验证：</strong>${escapeHtml(item.next || "未记录")}\n${item.answer ? `<strong>解释：</strong>${escapeHtml(item.answer)}` : ""}</p>
      <details>
        <summary>写一版简单解释</summary>
        <textarea rows="5" data-answer-box="${item.id}" placeholder="用小学生能懂的话解释它，然后写下剩余漏洞。">${escapeHtml(item.answer || "")}</textarea>
        <button class="primary" data-save-answer="${item.id}">保存解释</button>
      </details>
      <div class="tag-row">${tagsHtml(item.tags)}</div>
    </article>
  `).join("");
}

function renderStats() {
  const today = todayISO();
  const open = state.questions.filter(q => q.status !== "answered").length;
  const answered = state.questions.filter(q => q.status === "answered").length;
  const todayDiaries = state.diaries.filter(d => d.date === today).length;
  const todayQuestions = state.questions.filter(q => q.date === today).length;
  const stats = document.getElementById("stats");
  if (stats) {
    stats.innerHTML = `
      <div class="stat"><strong>${state.diaries.length}</strong><span>全部日记</span></div>
      <div class="stat"><strong>${state.questions.length}</strong><span>全部疑问</span></div>
      <div class="stat"><strong>${open}</strong><span>待探索</span></div>
      <div class="stat"><strong>${answered}</strong><span>已解释</span></div>
    `;
  }
  document.getElementById("todayCount").textContent = `${todayDiaries} 篇日记 · ${todayQuestions} 个疑问`;
}

function renderToday() {
  const d = new Date();
  const week = d.toLocaleDateString("zh-CN", { weekday: "long" });
  const date = d.toLocaleDateString("zh-CN", { month: "short", day: "numeric" });
  document.getElementById("todayWeek").textContent = week;
  document.getElementById("todayDate").textContent = date;
}

function renderRandomQuestion() {
  const box = document.getElementById("randomQuestion");
  if (!box) return;
  const pool = state.questions.filter(q => q.status !== "answered");
  if (!pool.length) {
    box.className = "empty";
    box.innerHTML = "还没有未解决疑问。去记录一个“不懂”吧。";
    return;
  }
  if (!box.dataset.current) box.dataset.current = pool[Math.floor(Math.random() * pool.length)].id;
  const q = pool.find(item => item.id === box.dataset.current) || pool[0];
  box.className = "entry";
  box.innerHTML = `
    <h3>${escapeHtml(q.text)}</h3>
    <p class="entry-body"><strong>猜想：</strong>${escapeHtml(q.guess || "未记录")}\n<strong>下一步：</strong>${escapeHtml(q.next || "给它安排一个最小验证动作")}</p>
    <div class="tag-row">${tagsHtml(q.tags)}</div>
  `;
}

function renderAll() {
  renderToday();
  renderStats();
  renderDiaryList();
  renderQuestionList();
  renderRandomQuestion();
}

function exportMarkdown() {
  const lines = ["# Feynman Diary Export", ""];
  lines.push("## 日记", "");
  state.diaries.forEach(d => {
    lines.push(`### ${d.title}`);
    lines.push(`- 时间：${formatDateTime(d.createdAt)}`);
    lines.push(`- 心情：${d.mood || ""}`);
    lines.push(`- 标签：${(d.tags || []).join(", ")}`);
    lines.push("", d.body, "");
  });
  lines.push("## 疑问", "");
  state.questions.forEach(q => {
    lines.push(`### ${q.text}`);
    lines.push(`- 时间：${formatDateTime(q.createdAt)}`);
    lines.push(`- 状态：${statusLabel(q.status)}`);
    lines.push(`- 触发：${q.trigger || ""}`);
    lines.push(`- 猜想：${q.guess || ""}`);
    lines.push(`- 验证：${q.next || ""}`);
    lines.push(`- 标签：${(q.tags || []).join(", ")}`);
    if (q.answer) lines.push("", `解释：${q.answer}`);
    lines.push("");
  });
  downloadFile(`feynman-diary-${todayISO()}.md`, lines.join("\n"), "text/markdown;charset=utf-8");
}

function setupEvents() {
  document.getElementById("saveDiary").addEventListener("click", saveDiary);
  document.getElementById("saveQuestion").addEventListener("click", saveQuestion);
  document.getElementById("newPrompt").addEventListener("click", setPrompt);
  document.getElementById("diarySearch").addEventListener("input", renderDiaryList);
  document.getElementById("questionSearch").addEventListener("input", renderQuestionList);
  document.getElementById("questionStatusFilter").addEventListener("change", renderQuestionList);
  document.getElementById("clearDiarySearch").addEventListener("click", () => { document.getElementById("diarySearch").value = ""; renderDiaryList(); });
  document.getElementById("pickRandom").addEventListener("click", () => { document.getElementById("randomQuestion").dataset.current = ""; renderRandomQuestion(); });

  document.addEventListener("click", e => {
    const diaryDelete = e.target.dataset.deleteDiary;
    if (diaryDelete && confirm("删除这篇日记？")) {
      state.diaries = state.diaries.filter(item => item.id !== diaryDelete);
      saveState();
      showToast("已删除");
    }
    const questionDelete = e.target.dataset.deleteQuestion;
    if (questionDelete && confirm("删除这个疑问？")) {
      state.questions = state.questions.filter(item => item.id !== questionDelete);
      saveState();
      showToast("已删除");
    }
    const diaryEdit = e.target.dataset.editDiary;
    if (diaryEdit) {
      const item = state.diaries.find(d => d.id === diaryEdit);
      if (!item) return;
      editingDiaryId = item.id;
      document.getElementById("diaryTitle").value = item.title;
      document.getElementById("diaryMood").value = item.mood || "平静";
      document.getElementById("diaryBody").value = item.body;
      document.getElementById("diaryTags").value = (item.tags || []).join(", ");
      document.getElementById("saveDiary").textContent = "更新日记";
      document.querySelector('[data-tab="write"]').click();
    }
    const questionEdit = e.target.dataset.editQuestion;
    if (questionEdit) {
      const item = state.questions.find(q => q.id === questionEdit);
      if (!item) return;
      editingQuestionId = item.id;
      document.getElementById("questionText").value = item.text;
      document.getElementById("questionTrigger").value = item.trigger || "";
      document.getElementById("questionGuess").value = item.guess || "";
      document.getElementById("questionNext").value = item.next || "";
      document.getElementById("questionTags").value = (item.tags || []).join(", ");
      document.getElementById("saveQuestion").textContent = "更新疑问";
      document.querySelector('[data-tab="write"]').click();
    }
    const statusId = e.target.dataset.status;
    if (statusId) {
      state.questions = state.questions.map(q => q.id === statusId ? { ...q, status: e.target.dataset.value, updatedAt: new Date().toISOString() } : q);
      saveState();
      showToast("状态已更新");
    }
    const saveAnswerId = e.target.dataset.saveAnswer;
    if (saveAnswerId) {
      const box = document.querySelector(`[data-answer-box="${saveAnswerId}"]`);
      state.questions = state.questions.map(q => q.id === saveAnswerId ? { ...q, answer: box.value.trim(), status: box.value.trim() ? "answered" : q.status, updatedAt: new Date().toISOString() } : q);
      saveState();
      showToast("解释已保存");
    }
  });

  document.getElementById("exportJson").addEventListener("click", () => {
    downloadFile(`feynman-diary-${todayISO()}.json`, JSON.stringify(state, null, 2), "application/json;charset=utf-8");
  });
  document.getElementById("exportMarkdown").addEventListener("click", exportMarkdown);
  document.getElementById("importJson").addEventListener("change", async e => {
    const file = e.target.files[0];
    if (!file) return;
    try {
      const parsed = JSON.parse(await file.text());
      if (!Array.isArray(parsed.diaries) || !Array.isArray(parsed.questions)) throw new Error("bad format");
      state = parsed;
      saveState();
      showToast("导入成功");
    } catch {
      showToast("导入失败：JSON 格式不对");
    }
  });
  document.getElementById("wipeData").addEventListener("click", () => {
    if (confirm("确认清空全部日记和疑问？这个操作不可撤销。")) {
      state = { diaries: [], questions: [] };
      saveState();
      showToast("已清空");
    }
  });
}


let deferredInstallPrompt = null;
const installBox = document.getElementById("installBox");
const installAppButton = document.getElementById("installApp");

window.addEventListener("beforeinstallprompt", event => {
  event.preventDefault();
  deferredInstallPrompt = event;
  if (installBox) installBox.hidden = false;
});

if (installAppButton) {
  installAppButton.addEventListener("click", async () => {
    if (!deferredInstallPrompt) {
      showToast("如果没有弹出安装，请点浏览器菜单里的‘添加到主屏幕’");
      return;
    }
    deferredInstallPrompt.prompt();
    await deferredInstallPrompt.userChoice.catch(() => null);
    deferredInstallPrompt = null;
    if (installBox) installBox.hidden = true;
  });
}

window.addEventListener("appinstalled", () => {
  deferredInstallPrompt = null;
  if (installBox) installBox.hidden = true;
  showToast("安装完成，可以从桌面打开了");
});

if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("service-worker.js").catch(() => {}));
}

setupTabs();
setupEvents();
setPrompt();
renderAll();
